Set objPlayer = CreateObject("WMPlayer.OCX")
objPlayer.settings.setMode "loop", True
objPlayer.settings.volume = 100
objPlayer.URL = WScript.Arguments(0)
objPlayer.controls.play
Do While True
    WScript.Sleep 1000
Loop