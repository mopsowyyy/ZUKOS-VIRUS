::[Bat To Exe Converter]
::
::YAwzoRdxOk+EWAnk
::fBw5plQjdG8=
::YAwzuBVtJxjWCl3EqQJgSA==
::ZR4luwNxJguZRRnk
::Yhs/ulQjdF+5
::cxAkpRVqdFKZSjk=
::cBs/ulQjdF+5
::ZR41oxFsdFKZSDk=
::eBoioBt6dFKZSDk=
::cRo6pxp7LAbNWATEpCI=
::egkzugNsPRvcWATEpCI=
::dAsiuh18IRvcCxnZtBJQ
::cRYluBh/LU+EWAnk
::YxY4rhs+aU+JeA==
::cxY6rQJ7JhzQF1fEqQJQ
::ZQ05rAF9IBncCkqN+0xwdVs0
::ZQ05rAF9IAHYFVzEqQJQ
::eg0/rx1wNQPfEVWB+kM9LVsJDGQ=
::fBEirQZwNQPfEVWB+kM9LVsJDGQ=
::cRolqwZ3JBvQF1fEqQJQ
::dhA7uBVwLU+EWDk=
::YQ03rBFzNR3SWATElA==
::dhAmsQZ3MwfNWATElA==
::ZQ0/vhVqMQ3MEVWAtB9wSA==
::Zg8zqx1/OA3MEVWAtB9wSA==
::dhA7pRFwIByZRRnk
::Zh4grVQjdCyDJGyX8VAjFDZbXBeNK3KjH4k47fvw++WXnkUUXe8lbYTUyYiGKeke8FDveoVj02Jf+A==
::YB416Ek+ZG8=
::
::
::978f952a14a936cc963da21a135fa983
@echo off
set "ps=%temp%\prank.ps1"
set "ASSETDIR=%~dp0"
(
echo Add-Type -AssemblyName System.Windows.Forms
echo Add-Type -AssemblyName System.Drawing
echo $folder = '%ASSETDIR%'
echo $img = Join-Path $folder 'hiimzukos.png'
echo $url1 = Join-Path $folder 'hey-its-me-its-verity-song.wav'
echo $url2 = Join-Path $folder 'voice-message.wav'
echo $url3 = Join-Path $folder 'dennish18-biohazard-alarm-143105.wav'
echo $colors = @^('Red','Blue','Green','Yellow','Purple','Orange','Pink'^)
echo $titles = @^('ZUKOS','ZUKOS!','OJOJ'^)
echo $scr = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
echo $sw = $scr.Width
echo $sh = $scr.Height
echo $vp = New-Object System.Media.SoundPlayer ^(Join-Path $folder 'voice-message.wav'^)
echo $vp.Load^(^)
echo function PlayLoop {
echo     param^([string]$u^)
echo     Start-Process wscript -ArgumentList ^("`"${folder}audioplay.vbs`" `"$u`""^) -WindowStyle Hidden
echo }
echo $fs = New-Object System.Windows.Forms.Form
echo $fs.WindowState = 'Maximized'
echo $fs.FormBorderStyle = 'None'
echo $fs.TopMost = $false
echo $fs.Bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
echo $fspb = New-Object System.Windows.Forms.PictureBox
echo $fspb.Image = [System.Drawing.Image]::FromFile^($img^)
echo $fspb.SizeMode = 'StretchImage'
echo $fspb.Dock = 'Fill'
echo $fs.Controls.Add^($fspb^)
echo $wins = New-Object System.Collections.ArrayList
echo $spawnTimer = New-Object System.Windows.Forms.Timer
echo $spawnTimer.Interval = 50
echo $spawnTimer.Add_Tick^({
echo     $fw = New-Object System.Windows.Forms.Form
echo     $fw.Text = ^($titles ^| Get-Random^)
echo     $fw.Size = New-Object System.Drawing.Size^(200,220^)
echo     $x = Get-Random -Minimum 0 -Maximum ^($sw - 200^)
echo     $y = Get-Random -Minimum 0 -Maximum ^($sh - 220^)
echo     $fw.Location = New-Object System.Drawing.Point^($x,$y^)
echo     $fw.BackColor = [System.Drawing.Color]::FromName^(^($colors ^| Get-Random^)^)
echo     $fw.TopMost = $true
echo     $pb = New-Object System.Windows.Forms.PictureBox
echo     $pb.Image = [System.Drawing.Image]::FromFile^($img^)
echo     $pb.SizeMode = 'StretchImage'
echo     $pb.Dock = 'Fill'
echo     $fw.Controls.Add^($pb^)
echo     $fw.Show^(^)
echo     $vp.Play^(^)
echo     $dirs = @^(-1,1^)
echo     $vx = ^(Get-Random -Minimum 5 -Maximum 20^) * ^($dirs ^| Get-Random^)
echo     $vy = ^(Get-Random -Minimum 5 -Maximum 20^) * ^($dirs ^| Get-Random^)
echo     $wins.Add^([PSCustomObject]@{F=$fw;VX=$vx;VY=$vy}^) ^| Out-Null
echo }^)
echo $moveTimer = New-Object System.Windows.Forms.Timer
echo $moveTimer.Interval = 20
echo $moveTimer.Add_Tick^({
echo     $rem = @^(^)
echo     foreach ^($w in $wins^) {
echo         if ^($w.F.IsDisposed^) { $rem += $w; continue }
echo         $nx = $w.F.Left + $w.VX
echo         $ny = $w.F.Top + $w.VY
echo         if ^($nx -le 0 -or $nx -ge ^($sw - 200^)^) { $w.VX = -$w.VX; $nx = $w.F.Left + $w.VX }
echo         if ^($ny -le 0 -or $ny -ge ^($sh - 220^)^) { $w.VY = -$w.VY; $ny = $w.F.Top + $w.VY }
echo         $w.F.Location = New-Object System.Drawing.Point^([int]$nx,[int]$ny^)
echo     }
echo     foreach ^($r in $rem^) { $wins.Remove^($r^) }
echo }^)
echo $app = New-Object System.Windows.Forms.Form
echo $app.Opacity = 0
echo $app.Size = New-Object System.Drawing.Size^(1,1^)
echo $app.Add_Shown^({
echo     [System.Windows.Forms.MessageBox]::Show^('hi im zukos','ERROR',0,16^) ^| Out-Null
echo     $fs.Show^(^)
echo     PlayLoop $url1
echo     PlayLoop $url2
echo     PlayLoop $url3
echo     $spawnTimer.Start^(^)
echo     $moveTimer.Start^(^)
echo }^)
echo [System.Windows.Forms.Application]::Run^($app^)
) > "%ps%"
powershell -ExecutionPolicy Bypass -File "%ps%"
del "%ps%"